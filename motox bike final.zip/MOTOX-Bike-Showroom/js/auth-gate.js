// MOTOX authentication gate
// Login is required before any showroom page can be opened.
(function () {
  const page = location.pathname.split("/").pop() || "index.html";
  const publicPages = ["login.html", "register.html"];
  const loggedIn = localStorage.getItem("motoxLoggedIn") === "true";

  if (!loggedIn && !publicPages.includes(page)) {
    location.replace("login.html");
  }
})();
